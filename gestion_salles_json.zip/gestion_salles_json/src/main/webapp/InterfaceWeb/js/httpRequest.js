$(document).ready(function(){

})

function gererEtatBoutonAutom() {
	if($('#gestionAutom').attr('class') == 'btn btn-outline-secondary mb-3') {
		$('#gestionAutom').attr('class', 'btn btn-outline-success mb-3');
	} else {
		$('#gestionAutom').attr('class', 'btn btn-outline-secondary mb-3');
	}
}

function requestHTTPGetCharger(urlIn) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "GET",
			beforeSend: function(request) {
  			},
			success: function(result){
				console.log(result)
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPGet(urlIn) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "GET",
			beforeSend: function(request) {
  			},
			success: function(result){
				console.log(result)
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPGetOnOff(urlIn, chemin) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "GET",
			success:function(result){	
				if(result == "true")
					$(chemin).prop("checked", true); 
				else
					$(chemin).prop("checked", false);
				console.log(chemin);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPGetValueThermo(urlIn, chemin) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "GET",
			success:function(result){
					$(chemin).html(result+' °C');
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPPut(urlIn) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "PUT",
			beforeSend: function(request) {
  			},
			success: function(result){
				console.log(result);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPPostLumiere(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
				$(cheminId).attr('onclick', 'requestHTTPPut(\'lampe/FL/'+result+'\');');
				$(cheminId).attr('id', 'lampe-'+result);
				setInterval(function(){requestHTTPGetOnOff('lampe/GL/'+result, '#lampe-'+result)}, 5000);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}
function requestHTTPPostPorte(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
				$(cheminId).attr('onclick', 'requestHTTPPut(\'porte/FL/'+result+'\');');
				$(cheminId).attr('id', 'porte-'+result);
				setInterval(function(){requestHTTPGetOnOff('porte/GL/'+result, '#porte-'+result)}, 5000);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}
function requestHTTPPostFenetre(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
				$(cheminId).attr('onclick', 'requestHTTPPut(\'fenetre/FL/'+result+'\');');
				$(cheminId).attr('id', 'fenetre-'+result);
				setInterval(function(){requestHTTPGetOnOff('fenetre/GL/'+result, '#fenetre-'+result)}, 5000);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}
function requestHTTPPostRadiateur(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
				$(cheminId).attr('onclick', 'requestHTTPPut(\'radiateur/FL/'+result+'\');');
				$(cheminId).attr('id', 'radiateur-'+result);
				setInterval(function(){requestHTTPGetOnOff('radiateur/GL/'+result, '#radiateur-'+result)}, 5000);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}
function requestHTTPPostThermo(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
				$(cheminId).attr('id', 'thermo-'+result);
				setInterval(function(){requestHTTPGetValueThermo('thermo/GL/'+result, '#thermo-'+result)}, 5000);
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function requestHTTPPost(urlIn, cheminId) {
	$.ajax({
			url: 'http://localhost:8080/gestion_salles_json/webapi/' + urlIn,
			type: "POST",
			beforeSend: function(request) {
  			},
			success: function(result){
			},
			error:function(error){
				console.log('Error ${error}')
			}
	})
}

function ajouterSalle(nomSalle, countSalle) {
	var HTML = '<div class="col-sm-12 text-center jumbotron p-3 salle" id="'+countSalle+'">'+
	$('#ensembleSalles').children('#0').html() +
	'</div>';

	$('#ensembleSalles').append(HTML);
	$('#ensembleSalles').children('#'+countSalle).find('h1').html(nomSalle);


	$('#'+countSalle+' #lampe0').attr('id', 'lampe'+countSalle+'-0');
	$('#'+countSalle+' #nomLumiere').attr('id', 'nomLumiere'+countSalle);
	$('#'+countSalle+' #porte0').attr('id', 'porte'+countSalle+'-0');
	$('#'+countSalle+' #nomPorte').attr('id', 'nomPorte'+countSalle);
	$('#'+countSalle+' #fenetre0').attr('id', 'fenetre'+countSalle+'-0');
	$('#'+countSalle+' #nomFenetre').attr('id', 'nomFenetre'+countSalle);
	$('#'+countSalle+' #radiateur0').attr('id', 'radiateur'+countSalle+'-0');
	$('#'+countSalle+' #nomRadiateur').attr('id', 'nomRadiateur'+countSalle);
	$('#'+countSalle+' #thermo0').attr('id', 'thermo'+countSalle+'-0');
	$('#'+countSalle+' #nomThermo').attr('id', 'nomThermo'+countSalle);
	$('#'+countSalle+' #regulationTemp').attr('id', 'regulationTemp'+countSalle);
	requestHTTPPost('salle/create/'+nomSalle);
	//$('#'+countSalle+' .lumieres').children('li').attr('id') = 'lampe'+countSalle+'-0';
}

function chargerSalle(nomSalle, countSalle) {
	var HTML = '<div class="col-sm-12 text-center jumbotron p-3 salle" id="'+countSalle+'">'+
	$('#ensembleSalles').children('#0').html() +
	'</div>';

	$('#ensembleSalles').append(HTML);
	$('#ensembleSalles').children('#'+countSalle).find('h1').html(nomSalle);


	$('#'+countSalle+' #lampe0').attr('id', 'lampe'+countSalle+'-0');
	$('#'+countSalle+' #nomLumiere').attr('id', 'nomLumiere'+countSalle);
}

function ajouterLumiere(nomLumiere, numSalle, countLumiere) {
	var HTML = '<li class="list-group-item" id="lampe'+numSalle+'-'+countLumiere+'">' +
	$('#lampe0').html() +
	'</div>';

	$('#lampe'+numSalle+'-0').parent().append(HTML);
	$('#lampe'+numSalle+'-'+countLumiere).find('h6').html(nomLumiere);
	
	requestHTTPPostLumiere('lampe/new/'+$('#nomLumiere'+numSalle).val()+'/'+numSalle, '#lampe'+numSalle+'-'+countLumiere+' #testCheck');
}

function chargerLumiere(nomLumiere, numSalle, countLumiere) {
	var HTML = '<li class="list-group-item" id="lampe'+numSalle+'-'+countLumiere+'">' +
	$('#lampe0').html() +
	'</div>';

	$('#lampe'+numSalle+'-0').parent().append(HTML);
	$('#lampe'+numSalle+'-'+countLumiere).find('h6').html(nomLumiere);
}

function ajouterPorte(nomPorte, numSalle, countPorte) {
	var HTML = '<li class="list-group-item" id="porte'+numSalle+'-'+countPorte+'">' +
	$('#porte0').html() +
	'</div>';

	$('#porte'+numSalle+'-0').parent().append(HTML);
	$('#porte'+numSalle+'-'+countPorte).find('h6').html(nomPorte);
	
	requestHTTPPostPorte('porte/new/'+$('#nomPorte'+numSalle).val()+'/'+numSalle, '#porte'+numSalle+'-'+countPorte+' #testCheck');
}

function chargerPorte(nomPorte, numSalle, countPorte) {
	var HTML = '<li class="list-group-item" id="porte'+numSalle+'-'+countPorte+'">' +
	$('#porte0').html() +
	'</div>';

	$('#porte'+numSalle+'-0').parent().append(HTML);
	$('#porte'+numSalle+'-'+countPorte).find('h6').html(nomPorte);
}

function ajouterFenetre(nomFenetre, numSalle, countFenetre) {
	var HTML = '<li class="list-group-item" id="fenetre'+numSalle+'-'+countFenetre+'">' +
	$('#fenetre0').html() +
	'</div>';

	$('#fenetre'+numSalle+'-0').parent().append(HTML);
	$('#fenetre'+numSalle+'-'+countFenetre).find('h6').html(nomFenetre);
	
	requestHTTPPostFenetre('fenetre/new/'+$('#nomFenetre'+numSalle).val()+'/'+numSalle, '#fenetre'+numSalle+'-'+countFenetre+' #testCheck');
}

function chargerFenetre(nomFenetre, numSalle, countFenetre) {
	var HTML = '<li class="list-group-item" id="fenetre'+numSalle+'-'+countFenetre+'">' +
	$('#fenetre0').html() +
	'</div>';

	$('#fenetre'+numSalle+'-0').parent().append(HTML);
	$('#fenetre'+numSalle+'-'+countFenetre).find('h6').html(nomFenetre);
}

function ajouterRadiateur(nomRadiateur, numSalle, countRadiateur) {
	var HTML = '<li class="list-group-item" id="radiateur'+numSalle+'-'+countRadiateur+'">' +
	$('#radiateur0').html() +
	'</div>';

	$('#radiateur'+numSalle+'-0').parent().append(HTML);
	$('#radiateur'+numSalle+'-'+countRadiateur).find('h6').html(nomRadiateur);
	
	requestHTTPPostRadiateur('radiateur/new/'+$('#nomRadiateur'+numSalle).val()+'/'+numSalle, '#radiateur'+numSalle+'-'+countRadiateur+' #testCheck');
}

function chargerRadiateur(nomRadiateur, numSalle, countRadiateur) {
	var HTML = '<li class="list-group-item" id="radiateur'+numSalle+'-'+countRadiateur+'">' +
	$('#radiateur0').html() +
	'</div>';

	$('#radiateur'+numSalle+'-0').parent().append(HTML);
	$('#radiateur'+numSalle+'-'+countRadiateur).find('h6').html(nomRadiateur);
}

function ajouterThermo(nomThermo, numSalle, countThermo) {
	var HTML = '<li class="list-group-item" id="thermo'+numSalle+'-'+countThermo+'">' +
	$('#thermo0').html() +
	'</div>';

	$('#thermo'+numSalle+'-0').parent().append(HTML);

	if(nomThermo == 'thermoInterieur') {
		$('#thermo'+numSalle+'-'+countThermo).find('h6').html(('Thermomètre intérieur'));
	} else {
		$('#thermo'+numSalle+'-'+countThermo).find('h6').html(('Thermomètre extérieur'));
	}
	
	requestHTTPPostThermo('thermo/new/'+nomThermo+'/AHUTC/'+numSalle, '#thermo'+numSalle+'-'+countThermo+' #testCheck');
}

function chargerThermo(nomThermo, numSalle, countThermo) {
	var HTML = '<li class="list-group-item" id="thermo'+numSalle+'-'+countThermo+'">' +
	$('#thermo0').html() +
	'</div>';

	$('#thermo'+numSalle+'-0').parent().append(HTML);
	$('#thermo'+numSalle+'-'+countThermo).find('h6').html(nomThermo);
}