package fr.insa.soa.gestion_salles_json;
import java.util.ArrayList;

import fr.insa.soa.gestion_salles_json.Lampe;

public class GestionLampes {
	public static ArrayList<Lampe> tab_lampes = new ArrayList<Lampe>();
	
	// création d'une lampe et ajout au tableau
	public int creationLampe(String numSerie, int salle) {
		Lampe lampe_1 = new Lampe(numSerie, salle);
		tab_lampes.add(lampe_1);
		System.out.println("Lampe " + lampe_1.getId() + " créé !");
		return lampe_1.getId();
	}
		
	// change l'état d'une lampe
	public void update(int idLampe, boolean state) {
		for (Lampe n: tab_lampes) {
			if (n.getId() == idLampe) {
				n.setState(true);
			}
		}
	}
	
	// récupére l'indice d'une lampe avec son numéro de série
	public int indice (String numSerie) {
		for(Lampe n: tab_lampes) {
			System.out.println(numSerie);
			if (n.getNumSerie().equals(numSerie)) {
				return n.getId();
			}
		}
		return -1;
	}
	
	// Eteint toutes les lampes
	
	
	public void allOff() {
		for (Lampe n: tab_lampes) {		
			n.setState(false);			
		}
	}
	
	// Allume toutes les lampes
	public void allOn() {
		for (Lampe n: tab_lampes) {		
			n.setState(true);			
		}
	}
	
	
	
	// Allume toutes les lampes d'une salle
	public void updateSalle(int ID_salle, boolean state) {
		for (Lampe n: tab_lampes) {		
			if (n.getIdSalle() == ID_salle) {
				n.setState(state);
			}
		}
	}	
}
