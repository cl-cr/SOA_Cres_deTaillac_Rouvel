package fr.insa.soa.gestion_salles_json;

import java.util.ArrayList;

public class GestionRadiateurs {
	public static ArrayList<Radiateur> tab_radiateurs = new ArrayList<Radiateur>();
	
	// création d'un radiateur et ajout au tableau
	public int creationRadiateur(String numSerie, int salle) {
		Radiateur radiateur = new Radiateur(numSerie, salle);
		tab_radiateurs.add(radiateur);
		System.out.println("Radiateur " + radiateur.getId() + " créé !");
		return radiateur.getId();
	}
	
	// change l'état d'un radiateur
	public void update(int idRadiateur, boolean state, int temperature) {
		for (Radiateur n: tab_radiateurs) {
			n.setState(state);
			n.setTemp(temperature);
		}
	}
	
	// récupére l'indice d'un radiateur avec son numéro de série
	public int indice (String numSerie) {
		for (Radiateur n: tab_radiateurs) {
			System.out.println(numSerie);
			if(n.getNumSerie().equals(numSerie)) {
				return n.getId();
			}
		}
		return -1;
	}
	
	// Eteint tous les radiateurs
	public void allOff() {
		for (Radiateur n: tab_radiateurs) {
			n.setState(false);
		}
	}
	
	// Allume tous les radiateurs
	public void allOn(int temp) {
		for (Radiateur n: tab_radiateurs) {
			n.setState(true);
			n.setTemp(temp);
		}
	}
	
	// Allume un ensemble de radiateurs donné
	public void updateTAB(int[] tab_ID, boolean state, int temp) {
		for (Radiateur n: tab_radiateurs) {
			n.setState(state);
			n.setTemp(temp);
		}
	}
	
	// Allume tous les radiateurs d'une salle
	public void updateSalle(int ID_salle, boolean state, int temp) {
		for (Radiateur n: tab_radiateurs) {
			if(n.getIdSalle() == ID_salle) {
				n.setState(state);
				n.setTemp(temp);
			}
		}
	}	
}

