package fr.insa.soa.gestion_salles_json;

public class Radiateur {
	private static int compteur = 0;
	private int id;
	private String numSerie;
	private boolean state;
	private int id_Salle;
	private int temperature;
	
	// constructor
	public Radiateur(String numSerieIn, int salle) {
		compteur++;
		id = compteur;
		numSerie = numSerieIn;
		System.out.println("YOLO Radiateur ajoutée !");
		id_Salle = salle;
		temperature = 18;
	}
	
	// setteur
	public void setState(boolean state_in) {
		this.state = state_in;
	}
	
	public void setTemp(int temp) {
		this.temperature = temp;
	}
	
	// getteur
	public int getId() {
		return this.id;
	}
	
	public int getIdSalle() {
		return this.id_Salle;
	}
	
	public boolean getState() {
		return this.state;
	}
	
	public String getNumSerie() {
		return this.numSerie;
	}
	
	// méthode
	public void flip() {
		this.state = !this.state;
	}
}
