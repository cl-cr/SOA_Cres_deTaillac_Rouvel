package fr.insa.soa.gestion_salles_json;

import java.util.*;
import fr.insa.soa.gestion_salles_json.GestionThermometres;
import fr.insa.soa.gestion_salles_json.GestionRadiateurs;
import fr.insa.soa.gestion_salles_json.GestionFenetres;

public class GestionTemperature {
	
	private boolean state = false;
	
	GestionThermometres gThermo = new GestionThermometres();
	GestionFenetres gFenetres = new GestionFenetres();
	GestionRadiateurs gRadiateurs = new GestionRadiateurs();	
	
	public ArrayList<Integer> getListeSalles() {
		ArrayList<Integer> listeSalles = new ArrayList<Integer>();
		for (Thermometre n: gThermo.tab_Thermometres) {
			listeSalles.add(n.getIdSalle());  
		}
		return listeSalles;
	}
	
	public void set_state (boolean state_in) {
		this.state = state_in;
	}
	
	public boolean get_state () {
		return this.state;
	}
	
	public void gererTemperature(boolean gestion_auto) {
		
		while (gestion_auto == true) {
			
			// récupère la température des salle et chauffe / ouvre les fenêtres en fonction de la température de consigne
			for (Integer n: getListeSalles()) {
				// si temp différente de consigne
				if (gThermo.getTempSalle(n) != gThermo.getConsigneSalle(n)) {
					
					if (gThermo.getTempSalle(n) < gThermo.getConsigneSalle(n)) {
						// rad on
						gRadiateurs.updateSalle(n, true, 0);
						if (gThermo.getTempSalle(n) < gThermo.getTempExt()) {
							gFenetres.updateSalle(n, true);							
						}
						else {
							gFenetres.updateSalle(n, false);
						}
					}
					
					else {
						// rad off
						gRadiateurs.updateSalle(n, false, 0);
						if (gThermo.getTempSalle(n) > gThermo.getTempExt()) {
							gFenetres.updateSalle(n, true);							
						}
						else {
							gFenetres.updateSalle(n, false);
						}
					}
					
					/*if (gThermo.getTempSalle(n) > gThermo.getConsigneSalle(n) && gThermo.getTempSalle(n) > (gThermo.getTempExt()+2)) {
						gFenetres.updateSalle(n, true);
						gRadiateurs.updateSalle(n, false, 0);
						System.out.println("Fenetres ouvertes et radiateurs éteints");
					}
					
					else if (gThermo.getTempSalle(n) > gThermo.getConsigneSalle(n) && gThermo.getTempSalle(n) <= (gThermo.getTempExt()+2)) {
						gFenetres.updateSalle(n, false);
						gRadiateurs.updateSalle(n, false, 0);
						System.out.println("Fenetres fermées et radiateurs éteints");;
					}
					
					else if (gThermo.getTempSalle(n) < gThermo.getConsigneSalle(n) && gThermo.getTempSalle(n) < (gThermo.getTempExt()-2)) {
						gFenetres.updateSalle(n, true);
						gRadiateurs.updateSalle(n, true, gThermo.getConsigneSalle(n));
						System.out.println("Fenetres ouvertes et radiateurs allumés");
					}
					
					else if (gThermo.getTempSalle(n) < gThermo.getConsigneSalle(n) && gThermo.getTempSalle(n) > (gThermo.getTempExt()-2)) {
						gFenetres.updateSalle(n, false);
						gRadiateurs.updateSalle(n, true, gThermo.getConsigneSalle(n));
						System.out.println("Fenetres fermées et radiateurs allumés");
					}*/
				}
			}
		}
	}
	
	public boolean flip() {
		this.state = !this.state;
		return this.state;
	}
}
