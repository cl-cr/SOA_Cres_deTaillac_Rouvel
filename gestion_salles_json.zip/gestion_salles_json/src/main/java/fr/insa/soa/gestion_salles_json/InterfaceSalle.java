package fr.insa.soa.gestion_salles_json;


import fr.insa.soa.gestion_salles_json.GestionLampes;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonValue;
import javax.json.JsonValue.ValueType;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import fr.insa.soa.gestion_salles_json.Salle;

@Path("salle")
public class InterfaceSalle {
	
	public static ArrayList<Salle> liste_salles = new ArrayList<Salle>();
	public static int id_salle = 0;		
	
	public GestionLampes GL = new GestionLampes(); 
	
	@POST
	@Path("create/{nom}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String ajouter_salle(@PathParam ("nom") String nom_salle) {
		Salle salle1 = new Salle(nom_salle);
		liste_salles.add(salle1);
		System.out.println(nom_salle + " ajoutée !");
		return "Nouvelle salle ajoutée !";
	}
	
	/*@GET
	@Path("onstart")
	@Consumes(MediaType.TEXT_PLAIN)
	public String onStart() {
		JsonArrayBuilder tab_json = Json.createArrayBuilder();
		for (Salle n: liste_salles) {
			tab_json.add(Json.createObjectBuilder()
					.add("nom_salle", n.getNomSalle())					
					);
		}
		
		return tab_json.toString();
	}*/
}
