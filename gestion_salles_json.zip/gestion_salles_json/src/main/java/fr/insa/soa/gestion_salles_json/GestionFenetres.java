package fr.insa.soa.gestion_salles_json;

import java.util.ArrayList;

public class GestionFenetres {
	public static ArrayList<Fenetre> tab_Fenetres = new ArrayList<Fenetre>();
	
	public int creationFenetre(String numSerie, int salle) {
		Fenetre fenetre = new Fenetre(numSerie, salle);
		tab_Fenetres.add(fenetre);
		System.out.println("Fenetre " + fenetre.getId() + " ajoutée !");
		return fenetre.getId();
	}
	
	public void update(int id_fenetre, boolean state) {
		for (Fenetre n: tab_Fenetres) {
			if (n.getId() == id_fenetre) {
				n.setState(state);
			}
		}
	}
	
	public int indice(String numSerie) {
		for (Fenetre n: tab_Fenetres) {
			if(n.getNumSerie().equals(numSerie)) {
				return n.getId();
			}
		}
		return -1;
	}
	
	// Eteint toutes les lampes
	public void allOff() {
		for (Fenetre n: tab_Fenetres) {
			n.setState(false);
		}
	}
	
	// Allume toutes les lampes
	public void allOn() {
		for (Fenetre n: tab_Fenetres) {
			n.setState(true);
		}
	}	
	
	// Ouvre fenetre d'une salle
	public void updateSalle(int ID_salle, boolean state) {
		for (Fenetre n: tab_Fenetres) {
			if(n.getIdSalle() == ID_salle) {
				n.setState(state);
			}
		}
	}	
}
