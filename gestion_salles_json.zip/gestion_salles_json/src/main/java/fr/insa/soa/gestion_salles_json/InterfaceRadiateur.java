package fr.insa.soa.gestion_salles_json;

import fr.insa.soa.gestion_salles_json.Radiateur;
import fr.insa.soa.gestion_salles_json.GestionRadiateurs;
import javax.ws.rs.*;
import javax.enterprise.inject.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("radiateur")
public class InterfaceRadiateur {
	
	public GestionRadiateurs radiateur_manager = new GestionRadiateurs();
	
	@POST
	@Path("new/{ns}/{ids}")
	//@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String creer_Radiateur(@PathParam("ns") String numSerie, @PathParam("ids") int id_salle) {		
		int res = radiateur_manager.creationRadiateur(numSerie, id_salle);
		System.out.println("Radiateur ajoutée !");
		return String.valueOf(res);
	}
	
	@GET
	@Path("GL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String get_state_radiateur(@PathParam("idl") int id_radiateur) {		
		for (Radiateur n: radiateur_manager.tab_radiateurs) {
			if (n.getId() == id_radiateur) {
				System.out.println("get "+id_radiateur);
				return String.valueOf(n.getState());
				
			}
		}
		
		return String.valueOf(false);
	}
	
	@PUT
	@Path("FL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String set_state_radiateur(@PathParam("idl") int id_radiateur) {
		for (Radiateur n: radiateur_manager.tab_radiateurs) {
			if (n.getId() == id_radiateur) {
				n.flip();
				System.out.println("flip : "+ n.getState());
				return "Flip done !";
			}
		}
		return "not done";
	}
	
	@PUT
	@Path("SOffL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String eteindre_Radiateur_salle(@PathParam("ids") int id_salle) {
		for (Radiateur n: radiateur_manager.tab_radiateurs) {
			if (n.getIdSalle()== id_salle) {
				n.setState(false);
				System.out.println("turn off : "+n.getState());
			}
		} 
		return "Done turn off all radiators";
	}
	
	@PUT
	@Path("SOnL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String allumer_radiateur_salle(@PathParam("ids") int id_salle) {
		for (Radiateur n: radiateur_manager.tab_radiateurs) {
			if (n.getIdSalle()== id_salle) {
				n.setState(true);
				System.out.println("turn on : "+n.getState());
			}
		} 
		return "Done turn on all radiators";
	}
}
