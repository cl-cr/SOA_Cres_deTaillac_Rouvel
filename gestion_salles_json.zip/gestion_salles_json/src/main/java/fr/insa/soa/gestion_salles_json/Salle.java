package fr.insa.soa.gestion_salles_json;

import java.util.ArrayList;

public class Salle {
	
	public String nom_salle;
	public static int id_salle=0;
	
	public Salle(String nom) {
		nom_salle = nom;
		id_salle++;
	}
	
	public String getNomSalle() {
		return this.nom_salle;
	}
	
	public int getIdSalle() {
		return this.id_salle;
	}
}
