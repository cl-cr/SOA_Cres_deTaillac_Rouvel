package fr.insa.soa.gestion_salles_json;

import java.util.ArrayList;

public class GestionThermometres {
public static ArrayList<Thermometre> tab_Thermometres = new ArrayList<Thermometre>();
	
	public int creationThermometre(String numSerie, int salle, String type_Thermo) {
		Thermometre Thermometre = new Thermometre(numSerie, salle, type_Thermo);
		tab_Thermometres.add(Thermometre);
		System.out.println("Thermometre " + Thermometre.getId() + " ajouté !");
		return Thermometre.getId();
	}
	
	// Retourne la température pour un thermomètre donné
	public float getTemp(int id_Thermometre) {
		for (Thermometre n: tab_Thermometres) {
			if (n.getId() ==  id_Thermometre) {
				return n.getValue_temp();
			}
		}
		return -1;
	}
	
	// retourne le numéro de série d'un thermomètre
	public int indice(String numSerie) {
		for (Thermometre n: tab_Thermometres) {
			if(n.getNumSerie().equals(numSerie)) {
				return n.getId();
			}
		}
		return -1;
	}
	
	// Eteint tous les thermometres
	public void allOff() {
		for (Thermometre n: tab_Thermometres) {
			n.setState(false);
		}
	}
	
	// Allume tous les thermometres
	public void allOn() {
		for (Thermometre n: tab_Thermometres) {
			n.setState(true);
		}
	}
	
	// Retourne la température d'une salle
	public float getTempSalle(int ID_salle) {
		for (Thermometre n: tab_Thermometres) {
			if(n.getIdSalle() == ID_salle && n.getTypeThermo().equals("thermoInterieur")) {
				return n.getValue_temp();
			}
		}
		return -1;
	}
	
	// Retourne la température de consigne d'une salle
	public int getConsigneSalle(int ID_salle) {
		for (Thermometre n: tab_Thermometres) {
			if(n.getIdSalle() == ID_salle) {
				return n.getConsigne_temp();
			}
		}
		return -1;
	}
	
	// Renvoie la température exterieure
	public float getTempExt() {
		for (Thermometre n: tab_Thermometres) {
			if (n.getTypeThermo().equals("thermoExterieur")) {
				return n.getValue_temp();
			}
		}
		return -1;
	}
	

}
