package fr.insa.soa.gestion_salles_json;

import fr.insa.soa.gestion_salles_json.Lampe;
import fr.insa.soa.gestion_salles_json.GestionLampes;
import javax.ws.rs.*;
import javax.enterprise.inject.Produces;
import javax.ws.rs.core.MediaType;

@Path("gestionAutom")
public class InterfaceTemperature {
	
	public static GestionTemperature temp_manager = new GestionTemperature();
	
	@PUT
	@Path("FL")
	@Consumes(MediaType.TEXT_PLAIN)
	public String routine (@PathParam("flip") boolean flip) {
		temp_manager.flip();
		temp_manager.gererTemperature(temp_manager.get_state());
		if (temp_manager.get_state() == true) {
			System.out.println("Self management ON !");
			return "Self management ON !";
		}
		else {
			System.out.println("Self management OFF !");			
			return "Self management OFF !";
		}
	}
}
