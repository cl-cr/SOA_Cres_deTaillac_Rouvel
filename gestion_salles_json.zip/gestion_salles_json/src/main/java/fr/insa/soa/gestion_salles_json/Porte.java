package fr.insa.soa.gestion_salles_json;

public class Porte {
	private static int compteur = 0;
	private int id;
	private String numSerie;
	private boolean state;
	private int id_Salle;
	
	// constructor
	public Porte(String numSerieIn, int salle) {
		compteur++;
		id = compteur;
		numSerie = numSerieIn;
		System.out.println("YOLO porte ajoutée !");
		id_Salle = salle;
	}
	
	// setteur
	public void setState(boolean state_in) {
		this.state = state_in;
	}
	
	// getteur
	public int getId() {
		return this.id;
	}
	
	public int getIdSalle() {
		return this.id_Salle;
	}
	
	public boolean getState() {
		return this.state;
	}
	
	public String getNumSerie() {
		return this.numSerie;
	}
	
	// méthode
	public void flip() {
		this.state = !this.state;
	}

}
