package fr.insa.soa.gestion_salles_json;

import fr.insa.soa.gestion_salles_json.Fenetre;
import fr.insa.soa.gestion_salles_json.GestionFenetres;
import javax.ws.rs.*;
import javax.enterprise.inject.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("fenetre")
public class InterfaceFenetre {
	
	public GestionFenetres fenetre_manager = new GestionFenetres();
	
	@POST
	@Path("new/{ns}/{ids}")
	//@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String creer_fenetre(@PathParam("ns") String numSerie, @PathParam("ids") int id_salle) {		
		int res = fenetre_manager.creationFenetre(numSerie, id_salle);
		System.out.println("fenetre ajoutée !");
		return String.valueOf(res);
	}
	
	@GET
	@Path("GL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String get_state_lamp(@PathParam("idl") int id_fenetre) {		
		for (Fenetre n: fenetre_manager.tab_Fenetres) {
			if (n.getId() == id_fenetre) {
				//System.out.println("get "+id_fenetre);
				return String.valueOf(n.getState());
				
			}
		}
		
		return String.valueOf(false);
	}
	
	@PUT
	@Path("FL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String set_state_lamp(@PathParam("idl") int id_fenetre) {
		for (Fenetre n: fenetre_manager.tab_Fenetres) {
			if (n.getId() == id_fenetre) {
				n.flip();
				System.out.println("flip : "+n.getState());
				return "Flip done";
			}
		}
		return "Not done";
	}
	
	@PUT
	@Path("SOffL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String eteindre_fenetre_salle(@PathParam("ids") int id_salle) {
		for (Fenetre n: fenetre_manager.tab_Fenetres) {
			if (n.getIdSalle()== id_salle) {
				n.setState(false);
				System.out.println("turn off : "+n.getState());
			}
		} 
		return "done close windows'room";
	}
	
	@PUT
	@Path("SOnL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String allumer_fenetre_salle(@PathParam("ids") int id_salle) {
		for (Fenetre n: fenetre_manager.tab_Fenetres) {
			if (n.getIdSalle()== id_salle) {
				n.setState(true);
				System.out.println("turn on : "+n.getState());
			}
		} 
		return "done open windows'room";
	}
}
