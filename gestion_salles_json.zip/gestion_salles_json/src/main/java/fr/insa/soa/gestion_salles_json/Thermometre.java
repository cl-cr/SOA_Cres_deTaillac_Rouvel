package fr.insa.soa.gestion_salles_json;

public class Thermometre {
	private static int compteur = 0;
	private int id;
	private String numSerie;
	private boolean state;
	private int id_Salle;
	private String type_thermo; // respecter la norme : "thermoExterieur" / "thermoInterieur"
	private float value_temp;
	private int consigne_temp;
	
	// constructor
	public Thermometre(String numSerieIn, int salle, String type_thermoIn) {
		compteur++;
		id = compteur;
		numSerie = numSerieIn;
		type_thermo = type_thermoIn;
		System.out.println("YOLO Thermometre ajoutée !");
		id_Salle = salle;
	}
	
	// setteur
	public void setState(boolean state_in) {
		this.state = state_in;
	}
	
	public void setConsigne_temp(int consigne) {
		this.consigne_temp = consigne;
	}
	
	public void set_temp(float value) {
		this.value_temp = value;
	}
	
	// getteur
	public int getId() {
		return this.id;
	}
	
	public int getIdSalle() {
		return this.id_Salle;
	}
	
	public String getTypeThermo() {
		return this.type_thermo;
	}
	
	public boolean getState() {
		return this.state;
	}
	
	public String getNumSerie() {
		return this.numSerie;
	}
	
	public float getValue_temp() {
		float temp = (float)0.0;
		if (this.type_thermo.equals("thermoExterieur")) {
			temp = (float)(9.0 + Math.random());
			this.set_temp(temp);
			return temp;
		}
		else {
			temp = (float)(22.0 + Math.random());
			this.set_temp(temp);
			return temp;
		}
			
	}
	
	public int getConsigne_temp() {
		return this.consigne_temp;
	}
	// méthode
	public void flip() {
		this.state = !this.state;
	}
	
	public boolean reguler_temp() {
		if (this.getValue_temp() < this.getConsigne_temp()) {
			return true;
		}
		else
			return false;
	}

}
