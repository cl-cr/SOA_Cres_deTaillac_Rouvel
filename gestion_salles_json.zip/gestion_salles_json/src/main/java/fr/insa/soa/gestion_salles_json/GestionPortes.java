package fr.insa.soa.gestion_salles_json;

import java.util.ArrayList;

public class GestionPortes {
public static ArrayList<Porte> tab_Portes = new ArrayList<Porte>();
	
	public int creationPorte(String numSerie, int salle) {
		Porte Porte = new Porte(numSerie, salle);
		tab_Portes.add(Porte);
		System.out.println("Porte " + Porte.getId() + " ajoutée !");
		return Porte.getId();
	}
	
	public void update(int id_Porte, boolean state) {
		for (Porte n: tab_Portes) {
			if (n.getId() == id_Porte) {
				n.setState(state);
			}
		}
	}
	
	public int indice(String numSerie) {
		for (Porte n: tab_Portes) {
			if(n.getNumSerie().equals(numSerie)) {
				return n.getId();
			}
		}
		return -1;
	}
	
	// ferme toutes les portes
	public void allOff() {
		for (Porte n: tab_Portes) {
			n.setState(false);
		}
	}
	
	// Ouvre toutes les portes
	public void allOn() {
		for (Porte n: tab_Portes) {
			n.setState(true);
		}
	}
	
	
	// Allume toutes les portes d'une salle
	public void updateSalle(int ID_salle, boolean state) {
		for (Porte n: tab_Portes) {
			if(n.getIdSalle() == ID_salle) {
				n.setState(state);
			}
		}
	}	

}
