package fr.insa.soa.gestion_salles_json;

import fr.insa.soa.gestion_salles_json.Thermometre;
import fr.insa.soa.gestion_salles_json.GestionThermometres;
import javax.ws.rs.*;
import javax.enterprise.inject.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("thermo")
public class InterfaceThermometre {
	
	public GestionThermometres Thermometre_manager = new GestionThermometres();
	
	@POST
	@Path("new/{type}/{ns}/{ids}/")
	//@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String creer_Thermometre(@PathParam("type") String type, @PathParam("ns") String numSerie, @PathParam("ids") int id_salle) {		
		int res = Thermometre_manager.creationThermometre(numSerie, id_salle, type);
		System.out.println("Thermometre ajoutée !");
		return String.valueOf(res);
	}
	
	@GET
	@Path("GL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String get_state_lamp(@PathParam("idl") int id_Thermometre) {		
		for (Thermometre n: Thermometre_manager.tab_Thermometres) {
			if (n.getId() == id_Thermometre) {
				//System.out.println("get "+id_Thermometre);
				return String.valueOf(n.getValue_temp());
				
			}
		}
		
		return String.valueOf(false);
	}
	
	@PUT
	@Path("ST/{ids}/{consigne}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String set_state_lamp(@PathParam("ids") int id_salle, @PathParam("consigne") int consigne) {
		for (Thermometre n: Thermometre_manager.tab_Thermometres) {
			if (n.getIdSalle() == id_salle) {
				n.setConsigne_temp(consigne);
				System.out.println("Consigne salle "+ id_salle + " fixée à "+ consigne + " degrés");
				return String.valueOf(n.reguler_temp());								
			}
		}
		return "Not set up";
	}	
}
