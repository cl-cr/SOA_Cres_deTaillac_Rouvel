package fr.insa.soa.gestion_salles_json;

import fr.insa.soa.gestion_salles_json.Lampe;
import fr.insa.soa.gestion_salles_json.GestionLampes;
import javax.ws.rs.*;
import javax.enterprise.inject.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("lampe")
public class InterfaceLampe {
	
	public GestionLampes lampe_manager = new GestionLampes();
	
	@POST
	@Path("new/{ns}/{ids}")
	//@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	public String creer_lampe(@PathParam("ns") String numSerie, @PathParam("ids") int id_salle) {		
		int res = lampe_manager.creationLampe(numSerie, id_salle);
		System.out.println("Lampe ajoutée !");
		return String.valueOf(res);
	}
	
	@GET
	@Path("GL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String get_state_lamp(@PathParam("idl") int id_lampe) {		
		for (Lampe n: lampe_manager.tab_lampes) {
			if (n.getId() == id_lampe) {
				//System.out.println("get "+id_lampe);
				return String.valueOf(n.getState());
				
			}
		}
		
		return String.valueOf(false);
	}
	
	@PUT
	@Path("FL/{idl}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String set_state_lamp(@PathParam("idl") int id_lampe) {
		for (Lampe n: lampe_manager.tab_lampes) {
			if (n.getId() == id_lampe) {
				n.flip();
				System.out.println("flip : "+n.getState());
				return "done flip";
			}
		}
		return "not done";
	}
	
	@PUT
	@Path("SOffL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String eteindre_lampe_salle(@PathParam("ids") int id_salle) {
		for (Lampe n: lampe_manager.tab_lampes) {
			if (n.getIdSalle()== id_salle) {
				n.setState(false);
				System.out.println("turn off : "+n.getState());
			}
		} 
		return "done turn off light room";
	}
	
	@PUT
	@Path("SOnL/{ids}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String allumer_lampe_salle(@PathParam("ids") int id_salle) {
		for (Lampe n: lampe_manager.tab_lampes) {
			if (n.getIdSalle()== id_salle) {
				n.setState(true);
				System.out.println("turn on : "+n.getState());
			}
		} 
		return "done turn on light room";
	}
}
