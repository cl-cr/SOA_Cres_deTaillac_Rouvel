function ajouterFenetre(nomFenetre, numSalle, countFenetre) {
	var HTML = '<li class="list-group-item" id="fenetre'+nomFenetre+'-'+countFenetre+'">' +
	$('#fenetre0').html() +
	'</div>';

	$('#fenetre'+nomFenetre+'-0').parent().append(HTML);
	$('#fenetre'+nomFenetre+'-'+countFenetre).find('h6').html(nomFenetre);
	
	requestHTTPPostLumiere('fenetre/new/'+$('#nomFenetre'+nomFenetre).val()+'/'+nomFenetre, '#fenetre'+nomFenetre+'-'+countFenetre+' #testCheck');
}

function chargerFenetre(nomFenetre, numSalle, countFenetre) {
	var HTML = '<li class="list-group-item" id="fenetre'+nomFenetre+'-'+countFenetre+'">' +
	$('#fenetre0').html() +
	'</div>';

	$('#fenetre'+nomFenetre+'-0').parent().append(HTML);
	$('#fenetre'+nomFenetre+'-'+countFenetre).find('h6').html(nomFenetre);
}